/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class ChatServer {

    int port = 7777;//port number

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new ChatServer().service();//instantiate chatserver and start the service
    }

    public void service() {//waits for the request and hands over the request to "talk()" for processing/service
        ServerSocket listener = null;
        while (true) {//loop forever
            try {
                if (listener == null) {//if listener is not already created
                    listener = new ServerSocket(port);//create a ServerSocket on the given port number
                }
                Socket socket = listener.accept();//wait fo the connections from clients
                PrintWriter pw = new PrintWriter(socket.getOutputStream());//create object for sending data to the client
                BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));//create object for receiving data from the client
                talk(pw, br);//hand over the rest of the processeing and continue to wait for another request
            } catch (IOException ex) {
                Logger.getLogger(ChatServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }
    /*
    this method creates and displays the window
    and calls receive to keep checking for incoming messages
    all this is done using the PrintWritter and the BufferedReader object passed as parameters
    */
    void talk(PrintWriter pw, BufferedReader br) {
        Smain gui = new Smain(pw);//instantiate the JFrame form
        gui.setVisible(true);//display the form
        receive(br, gui);//call receive
    }
    /*
     creates a new thread that manages the receiption of messages from the client
    basically, this method reads the message from the client and displas it in a textbox
    */
    void receive(BufferedReader br, Smain gui) {
        new Thread() {//anonymous inner class extending Thread
            @Override
            public void run() {//overriding run() in Thread class
                while (true) {//keep waiting for the input
                    try {
                        String s = br.readLine();//read input from the client
                        gui.setReceivertxt(s);//display the input
                    } catch (IOException ex) {
                        Logger.getLogger(ChatServer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }.start();//start the thread
    }
}
