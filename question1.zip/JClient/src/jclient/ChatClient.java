package jclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author user
 */
public class ChatClient {

    String server = "localhost";//server name or address
    int port = 7777;//port used by the server

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new ChatClient().connect(); //instantiate the ClientChat and let it connect to the server
    }
    /*
    connect to the given server at a given port
    
    */
    public void connect() {
        Socket socket;
        try {
            socket = new Socket(server, port);
            PrintWriter pw = new PrintWriter(socket.getOutputStream());
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            talk(pw, br);
        } catch (IOException ex) {
            Logger.getLogger(ChatClient.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    void talk(PrintWriter pw, BufferedReader br) {
        Cmain gui = new Cmain(pw);
        gui.setVisible(true);
        receive(br, gui); 
    }

    void receive(BufferedReader br, Cmain gui) {
        new Thread() {
            @Override
            public void run() {
                while (true) {
                    try {
                        String s = br.readLine();
                        gui.setReceivertxt(s); 
                    } catch (IOException ex) {
                        Logger.getLogger(ChatClient.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }.start(); 
    }
}
